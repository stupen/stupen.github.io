
Thank you for downloading this freebie!

The freebie was made by [Taras Shypka](https://dribbble.com/bugsster) exclusively for [Codrops](http://www.codrops.com).

Use it freely in your personal and commercial projects but please do not republish or redistribute.

Check out some more freebies here: [Codrops Freebies](http://tympanus.net/codrops/category/freebies/)

Follow us on [Twitter](http://www.twitter.com/codrops), [Facebook](http://www.facebook.com/pages/Codrops/159107397912), [Google+](https://plus.google.com/101095823814290637419), [GitHub](https://github.com/codrops) and [Pinterest](http://www.pinterest.com/codrops/)
